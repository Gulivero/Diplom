package slavin.fit.bstu.quest;
import android.content.Context;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;

import java.util.ArrayList;
import java.util.List;

import slavin.fit.bstu.quest.Model.Image;
import slavin.fit.bstu.quest.Model.Quest;

public class DataAdapter extends RecyclerView.Adapter<DataAdapter.ViewHolder> {
    private List<Quest> questsList;
    private List<Quest> quests;
    private List<Image> imagesList;
    private Context context;

    public DataAdapter(Context context, List<Quest> questsList, List<Image> imagesList) {
        this.context = context;
        this.questsList = questsList;
        this.quests = questsList;
        this.imagesList = imagesList;

    }

    public void filter(String text) {
        questsList.clear();
        if(text.isEmpty()){
            questsList.addAll(quests);
        } else{
            text = text.toLowerCase();
            for(Quest quest: quests){
                if(quest.getName().toLowerCase().contains(text)){
                    questsList.add(quest);
                }
            }
        }
        notifyDataSetChanged();
    }

    @Override
    public DataAdapter.ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.row_layout, viewGroup, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder viewHolder, int i) {

        viewHolder.tv_androidName.setText(questsList.get(i).getName());
        viewHolder.tv_androidDescription.setText(questsList.get(i).getDescription());
        viewHolder.tv_androidReward.setText(questsList.get(i).getReward());
        for (Image image : imagesList) {
            if (image.getQuestId() != null && image.getQuestId() == questsList.get(i).getId())
                Glide.with(context).load(image.getImageRef()).into(viewHolder.img_android);
        }


    }

    @Override
    public int getItemCount() {
        return questsList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        TextView tv_androidName, tv_androidDescription, tv_androidReward;
        ImageView img_android;
        public ViewHolder(View view) {
            super(view);

            tv_androidName = (TextView)view.findViewById(R.id.tv_androidName);
            tv_androidDescription = (TextView)view.findViewById(R.id.tv_androidDescription);
            tv_androidReward = (TextView)view.findViewById(R.id.tv_androidReward);
            img_android = (ImageView)view.findViewById(R.id.img_android);
        }
    }
}