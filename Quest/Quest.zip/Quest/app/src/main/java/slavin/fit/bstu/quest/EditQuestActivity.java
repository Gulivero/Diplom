package slavin.fit.bstu.quest;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import slavin.fit.bstu.quest.API.NetworkService;
import slavin.fit.bstu.quest.Model.Quest;

public class EditQuestActivity extends AppCompatActivity {

    Button edit;
    EditText name, description, reward;
    Integer id;
    ArrayList<EditText> reginfoList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_editquest);

        edit = findViewById(R.id.editQuest);
        name = findViewById(R.id.nameEdit);
        description = findViewById(R.id.descriptionEdit);
        reward = findViewById(R.id.rewardEdit);

        reginfoList = new ArrayList<>();
        reginfoList.add(name);
        reginfoList.add(description);
        reginfoList.add(reward);

        ActionBar actionBar = getSupportActionBar();
        actionBar.setHomeButtonEnabled(true);
        actionBar.setDisplayHomeAsUpEnabled(true);

        Bundle bundle = getIntent().getExtras();
        id = bundle.getInt("id");

        NetworkService.getInstance()
                .getQuestApi()
                .GetQuest(id)
                .enqueue(new Callback<Quest>() {
                    @Override
                    public void onResponse(@NonNull Call<Quest> call, @NonNull Response<Quest> response) {
                        Quest quest = response.body();
                        String name1 = quest.getName();
                        String description1 = quest.getDescription();
                        String reward1 = quest.getReward();
                        name.setText(name1);
                        description.setText(description1);
                        reward.setText(reward1);
                    }

                    @Override
                    public void onFailure(@NonNull Call<Quest> call, @NonNull Throwable t) {
                        Toast.makeText(EditQuestActivity.this, t.getMessage(), Toast.LENGTH_LONG).show();
                        t.printStackTrace();
                    }
                });

        edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                edit();
            }
        });
    }

    public void edit() {

        for (EditText edit : reginfoList) {
            if (TextUtils.isEmpty(edit.getText())) {
                edit.setError("Заполните поле!");
                return;
            }
        }

        Quest quest = new Quest();
        quest.setName(name.getText().toString());
        quest.setDescription(description.getText().toString());
        quest.setReward(reward.getText().toString());

        NetworkService.getInstance()
                .getQuestApi()
                .EditQuest(id, quest)
                .enqueue(new Callback<String>() {
                    @Override
                    public void onResponse(@NonNull Call<String> call, @NonNull Response<String> response) {
                        Toast.makeText(EditQuestActivity.this, response.body(), Toast.LENGTH_LONG).show();
                        if (response.body().equals("Квест успешно изменён"))
                            back();
                    }

                    @Override
                    public void onFailure(@NonNull Call<String> call, @NonNull Throwable t) {
                        Toast.makeText(EditQuestActivity.this, t.getMessage(), Toast.LENGTH_LONG).show();
                        t.printStackTrace();
                    }
                });
    }

    public void back(){
        this.finish();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                this.finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
