package slavin.fit.bstu.quest;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import slavin.fit.bstu.quest.API.NetworkService;
import slavin.fit.bstu.quest.Model.Quest;
import slavin.fit.bstu.quest.Model.Request;
import slavin.fit.bstu.quest.Model.User;

public class CurrentQuestActivity extends AppCompatActivity {
    TextView name;
    TextView description;
    TextView reward;
    TextView author;
    TextView contractor;
    Button request, check;
    String username;
    int questId, userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_currentquest);

        name = findViewById(R.id.nameQuest);
        description = findViewById(R.id.descriptionQuest);
        reward = findViewById(R.id.rewardQuest);
        author = findViewById(R.id.authorQuest);
        contractor = findViewById(R.id.contractorQuest);
        request = findViewById(R.id.takeQuestButton);
        check = findViewById(R.id.checkContractorsButton);

        request.setVisibility(View.GONE);
        check.setVisibility(View.GONE);

        ActionBar actionBar = getSupportActionBar();
        actionBar.setHomeButtonEnabled(true);
        actionBar.setDisplayHomeAsUpEnabled(true);

        Bundle id = getIntent().getExtras();
        questId = id.getInt("id");
        username = id.getString("username");
        userId = id.getInt("userId");

        request.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addrequest();
            }
        });
        check.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setcontractor();
            }
        });

        NetworkService.getInstance()
                .getQuestApi()
                .GetQuest(questId)
                .enqueue(new Callback<Quest>() {
                    @Override
                    public void onResponse(@NonNull Call<Quest> call, @NonNull Response<Quest> response) {
                        Quest quest = response.body();
                        name.setText(quest.getName());
                        description.setText(quest.getDescription());
                        reward.setText(quest.getReward());
                        author.setText(quest.getAuthor());
                        contractor.setText(quest.getContractor());
                        if(quest.getContractor().equals("none")) {
                            request.setVisibility(View.VISIBLE);
                            check.setVisibility(View.GONE);
                        }
                        if(quest.getAuthor().equals(username)) {
                            request.setVisibility(View.GONE);
                            check.setVisibility(View.VISIBLE);
                        }
                    }

                    @Override
                    public void onFailure(@NonNull Call<Quest> call, @NonNull Throwable t) {
                        Toast.makeText(CurrentQuestActivity.this, t.getMessage(), Toast.LENGTH_LONG).show();
                        t.printStackTrace();
                    }
                });

    }

    @Override
    protected void onRestart() {
        super.onRestart();
        NetworkService.getInstance()
                .getQuestApi()
                .GetQuest(questId)
                .enqueue(new Callback<Quest>() {
                    @Override
                    public void onResponse(@NonNull Call<Quest> call, @NonNull Response<Quest> response) {
                        Quest quest = response.body();
                        name.setText(quest.getName());
                        description.setText(quest.getDescription());
                        reward.setText(quest.getReward());
                        author.setText(quest.getAuthor());
                        contractor.setText(quest.getContractor());
                        if(quest.getContractor().equals("none")) {
                            request.setVisibility(View.VISIBLE);
                            check.setVisibility(View.GONE);
                        }
                        if(quest.getAuthor().equals(username)) {
                            request.setVisibility(View.GONE);
                            check.setVisibility(View.VISIBLE);
                        }
                    }

                    @Override
                    public void onFailure(@NonNull Call<Quest> call, @NonNull Throwable t) {
                        Toast.makeText(CurrentQuestActivity.this, t.getMessage(), Toast.LENGTH_LONG).show();
                        t.printStackTrace();
                    }
                });

    }

    public void setcontractor(){
        Intent intent = new Intent(this, SetContractorActivity.class);
        intent.putExtra("id", questId);
        startActivity(intent);
    }

    public void addrequest(){
        Request newrequest = new Request();
        newrequest.setQuestId(questId);
        newrequest.setUserId(userId);
        NetworkService.getInstance()
                .getQuestApi()
                .AddRequest(newrequest)
                .enqueue(new Callback<String>() {
                    @Override
                    public void onResponse(@NonNull Call<String> call, @NonNull Response<String> response) {
                        Toast.makeText(CurrentQuestActivity.this, response.body(), Toast.LENGTH_LONG).show();
                    }

                    @Override
                    public void onFailure(@NonNull Call<String> call, @NonNull Throwable t) {
                        Toast.makeText(CurrentQuestActivity.this, t.getMessage(), Toast.LENGTH_LONG).show();
                        t.printStackTrace();
                    }
                });
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                this.finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
