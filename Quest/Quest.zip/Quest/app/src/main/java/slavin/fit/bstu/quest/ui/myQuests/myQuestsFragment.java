package slavin.fit.bstu.quest.ui.myQuests;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import slavin.fit.bstu.quest.API.NetworkService;
import slavin.fit.bstu.quest.AddQuestActivity;
import slavin.fit.bstu.quest.CurrentQuestActivity;
import slavin.fit.bstu.quest.CurrentUserActivity;
import slavin.fit.bstu.quest.EditQuestActivity;
import slavin.fit.bstu.quest.Model.Quest;
import slavin.fit.bstu.quest.Model.User;
import slavin.fit.bstu.quest.R;

public class myQuestsFragment extends Fragment {

    AdapterView.AdapterContextMenuInfo info;
    String username;
    int userid;
    private ListView listView;
    private Button displayButton;
    List<Map<String, String>> data = new ArrayList<Map<String, String>>();

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        View root = inflater.inflate(R.layout.fragment_myquests, container, false);


        listView = root.findViewById(R.id.list_quests);
        registerForContextMenu(listView);
        displayButton = root.findViewById(R.id.searchquests_button);

        Bundle bundle = getActivity().getIntent().getExtras();
        username = bundle.getString("username");
        userid = bundle.getInt("id");

        displayButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                display();
            }
        });
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener(){
            @Override
            public void onItemClick(AdapterView<?> parent, View v, int position, long id)
            {
                Intent intent = new Intent(getContext(), CurrentQuestActivity.class);
                Map<String, String> str = data.get(position);
                Integer needingId = Integer.parseInt(str.get("id"));
                intent.putExtra("id", needingId);
                intent.putExtra("username", username);
                startActivity(intent);
            }
        });
        setHasOptionsMenu(true);
        return root;
    }

    public void display() {
        data.clear();
        NetworkService.getInstance()
                .getQuestApi()
                .GetQuests()
                .enqueue(new Callback<List<Quest>>() {
                    @Override
                    public void onResponse(@NonNull Call<List<Quest>> call, @NonNull Response<List<Quest>> response) {
                        List<Quest> list = response.body();
                        for (Quest quest : list)
                        {
                            if(quest.getAuthor().equals(username))
                            {
                                Map<String, String> datum = new HashMap<String, String>(2);
                                Integer id = quest.getId();
                                datum.put("id", id.toString());
                                datum.put("name", quest.getName());
                                data.add(datum);
                            }
                        }
                        SimpleAdapter adapter = new SimpleAdapter(getContext(), data, android.R.layout.simple_list_item_2,
                                new String[] {"name", "id"}, new int[] {android.R.id.text1, android.R.id.text2});
                        listView.setAdapter(adapter);

                    }

                    @Override
                    public void onFailure(@NonNull Call<List<Quest>> call, @NonNull Throwable t) {
                        Toast.makeText(getActivity(), t.getMessage(), Toast.LENGTH_LONG).show();
                        t.printStackTrace();
                    }
                });
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        getActivity().onCreateContextMenu(menu, v, menuInfo);
        MenuInflater inflater = getActivity().getMenuInflater();
        inflater.inflate(R.menu.myquests_contextmenu, menu);
    }

    @Override
    public boolean onContextItemSelected(MenuItem item) {
      info = (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();
        switch (item.getItemId()) {
            case R.id.edit:
                AlertDialog.Builder builder2 = new AlertDialog.Builder(getContext());
                builder2.setTitle("Внимание").setPositiveButton("Да", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Map<String, String> str = data.get(info.position);
                        Integer needingId = Integer.parseInt(str.get("id"));
                        EditQuest(needingId);
                    }
                }).setNegativeButton("Нет", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                }).setMessage("Изменить квест?");
                AlertDialog dialog2 = builder2.create();
                dialog2.show();
                return true;

            case R.id.delete:
                AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
                builder.setTitle("Внимание").setPositiveButton("Да", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Map<String, String> str = data.get(info.position);
                        Integer needingId = Integer.parseInt(str.get("id"));
                        DeleteQuest(needingId);
                        display();
                    }
                }).setNegativeButton("Нет", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                }).setMessage("Удалить квест?");
                AlertDialog dialog = builder.create();
                dialog.show();
                return true;

            default:
                return super.onContextItemSelected(item);
        }
    }

    public void DeleteQuest(Integer id){
        NetworkService.getInstance()
                .getQuestApi()
                .DeleteQuest(id)
                .enqueue(new Callback<String>() {
                    @Override
                    public void onResponse(@NonNull Call<String> call, @NonNull Response<String> response) {
                        Toast.makeText(getActivity(), response.body(), Toast.LENGTH_LONG).show();
                    }

                    @Override
                    public void onFailure(@NonNull Call<String> call, @NonNull Throwable t) {
                        Toast.makeText(getActivity(), t.getMessage(), Toast.LENGTH_LONG).show();
                        t.printStackTrace();
                    }
                });
    }

    public void EditQuest(Integer id){
        Intent intent = new Intent(getContext(), EditQuestActivity.class);
        intent.putExtra("id", id);
        startActivity(intent);
    }

    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        // Inflate the menu; this adds items to the action bar if it is present.
        inflater.inflate(R.menu.myquests_menu, menu);
        super.onCreateOptionsMenu(menu, inflater);
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        switch(id){
            case R.id.action_add :
                Intent intent = new Intent(getContext(), AddQuestActivity.class);
                intent.putExtra("username", username);
                intent.putExtra("userid", userid);
                startActivity(intent);
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
