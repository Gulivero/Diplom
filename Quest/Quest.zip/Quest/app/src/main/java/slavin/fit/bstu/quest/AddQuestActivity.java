package slavin.fit.bstu.quest;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import slavin.fit.bstu.quest.API.NetworkService;
import slavin.fit.bstu.quest.Model.Quest;

public class AddQuestActivity extends AppCompatActivity {

    Button add;
    EditText name, description, reward;
    String username;
    int userid;
    ArrayList<EditText> reginfoList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_addquest);

        add = findViewById(R.id.addQuest);
        name = findViewById(R.id.name);
        description = findViewById(R.id.description);
        reward = findViewById(R.id.reward);

        reginfoList = new ArrayList<>();
        reginfoList.add(name);
        reginfoList.add(description);
        reginfoList.add(reward);

        ActionBar actionBar =getSupportActionBar();
        actionBar.setHomeButtonEnabled(true);
        actionBar.setDisplayHomeAsUpEnabled(true);

        Bundle bundle = getIntent().getExtras();
        username = bundle.getString("username");
        userid = bundle.getInt("userid");

        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                add();
            }
        });
    }

    public void add() {
        for (EditText edit : reginfoList) {
            if (TextUtils.isEmpty(edit.getText())) {
                edit.setError("Заполните поле!");
                return;
            }
        }

        Quest quest = new Quest();
        quest.setName(name.getText().toString());
        quest.setDescription(description.getText().toString());
        quest.setReward(reward.getText().toString());
        quest.setContractor("none");
        quest.setAuthor(username);
        quest.setAuthorId(userid);

        NetworkService.getInstance()
                .getQuestApi()
                .AddQuest(quest)
                .enqueue(new Callback<String>() {
                    @Override
                    public void onResponse(@NonNull Call<String> call, @NonNull Response<String> response) {
                        Toast.makeText(AddQuestActivity.this, response.body(), Toast.LENGTH_LONG).show();
                        if (response.body().equals("Квест успешно добавлен"))
                            back();
                    }

                    @Override
                    public void onFailure(@NonNull Call<String> call, @NonNull Throwable t) {
                        Toast.makeText(AddQuestActivity.this, t.getMessage(), Toast.LENGTH_LONG).show();
                        t.printStackTrace();
                    }
                });
    }

    public void back(){
        this.finish();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                this.finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
