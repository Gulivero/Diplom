package slavin.fit.bstu.quest.ui.allQuests;

import android.app.SearchManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import slavin.fit.bstu.quest.API.NetworkService;
import slavin.fit.bstu.quest.CurrentQuestActivity;
import slavin.fit.bstu.quest.CurrentUserActivity;
import slavin.fit.bstu.quest.DataAdapter;
import slavin.fit.bstu.quest.Model.Image;
import slavin.fit.bstu.quest.Model.Quest;
import slavin.fit.bstu.quest.Model.User;
import slavin.fit.bstu.quest.R;

public class allQuestsFragment extends Fragment {

    View root;
    DataAdapter adapter;
    String query;
    SearchView searchView;
    List<Map<String, String>> data = new ArrayList<Map<String, String>>();
    String username;
    int userId;
    List<Quest> listQuests;
    List<Image> listImages;
    RecyclerView recyclerView;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        root = inflater.inflate(R.layout.fragment_allquests, container, false);

        Bundle id = getActivity().getIntent().getExtras();
        username = id.getString("username");
        userId = id.getInt("id");


        setHasOptionsMenu(true);
        display();

        return root;
    }

    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        // Inflate the menu; this adds items to the action bar if it is present.
        inflater.inflate(R.menu.options_menu, menu);
        SearchManager searchManager = (SearchManager) getActivity().getSystemService(Context.SEARCH_SERVICE);
        searchView = (SearchView) menu.findItem(R.id.search).getActionView();
        searchView.setSearchableInfo(searchManager.getSearchableInfo(getActivity().getComponentName()));
        // Здесь можно указать будет ли строка поиска изначально развернута или свернута в значок
        searchView.setIconifiedByDefault(false);

        SearchView.OnQueryTextListener textChangeListener = new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextChange(String cs) {
                adapter.filter(searchView.getQuery().toString());
                initViews();
                return false;
            }

            @Override
            public boolean onQueryTextSubmit(String query) {
                adapter.filter(searchView.getQuery().toString());
                initViews();
                return false;
            }
        };
        searchView.setOnQueryTextListener(textChangeListener);

        super.onCreateOptionsMenu(menu, inflater);

    }


    public void display() {
        data.clear();
        NetworkService.getInstance()
                .getQuestApi()
                .GetQuests()
                .enqueue(new Callback<List<Quest>>() {
                    @Override
                    public void onResponse(@NonNull Call<List<Quest>> call, @NonNull Response<List<Quest>> response) {
//                        List<Quest> list = response.body();
                        listQuests = response.body();
                        NetworkService.getInstance()
                                .getQuestApi()
                                .GetImages()
                                .enqueue(new Callback<List<Image>>() {
                                    @Override
                                    public void onResponse(@NonNull Call<List<Image>> call, @NonNull Response<List<Image>> response) {
                                        listImages = response.body();
                                        initViews();
                                    }

                                    @Override
                                    public void onFailure(@NonNull Call<List<Image>> call, @NonNull Throwable t) {
                                        Toast.makeText(root.getContext(), t.getMessage(), Toast.LENGTH_LONG).show();
                                        t.printStackTrace();
                                    }
                                });

//                        for (Quest quest : list)
//                        {
//                            if (quest.getName().equals(query))
//                            {
//                                Map<String, String> datum = new HashMap<String, String>(2);
//                                Integer id = quest.getId();
//                                datum.put("id", id.toString());
//                                datum.put("name", quest.getName());
//                                data.add(datum);
//                            }
//                            else if (searchView.getQuery().toString().isEmpty())
//                            {
//                                Map<String, String> datum = new HashMap<String, String>(2);
//                                Integer id = quest.getId();
//                                datum.put("id", id.toString());
//                                datum.put("name", quest.getName());
//                                data.add(datum);
//                            }
//                        }
//                        adapter = new SimpleAdapter(root.getContext(), data, android.R.layout.simple_list_item_2,
//                                new String[] {"name", "id"}, new int[] {android.R.id.text1, android.R.id.text2});
//                        listView.setAdapter(adapter);
//                        listView.setOnItemClickListener(new AdapterView.OnItemClickListener(){
//                            @Override
//                            public void onItemClick(AdapterView<?> parent, View v, int position, long id)
//                            {
//                                Intent intent = new Intent(getContext(), CurrentQuestActivity.class);
//                                Map<String, String> str = data.get(position);
//                                Integer needingId = Integer.parseInt(str.get("id"));
//                                intent.putExtra("id", needingId);
//                                intent.putExtra("username", username);
//                                intent.putExtra("userId", userId);
//                                startActivity(intent);
//                            }
//                        });
                    }

                    @Override
                    public void onFailure(@NonNull Call<List<Quest>> call, @NonNull Throwable t) {
                        Toast.makeText(getActivity(), t.getMessage(), Toast.LENGTH_LONG).show();
                        t.printStackTrace();
                    }
                });
    }

    private void initViews(){
        recyclerView = (RecyclerView) root.findViewById(R.id.card_recycler_view);
        recyclerView.setHasFixedSize(true);
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(root.getContext());
        recyclerView.setLayoutManager(layoutManager);

        adapter = new DataAdapter(root.getContext(), listQuests, listImages);
        recyclerView.setAdapter(adapter);

    }
}
