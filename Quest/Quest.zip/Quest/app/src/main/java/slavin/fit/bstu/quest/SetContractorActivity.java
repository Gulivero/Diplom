package slavin.fit.bstu.quest;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.ContextMenu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import slavin.fit.bstu.quest.API.NetworkService;
import slavin.fit.bstu.quest.Model.Quest;
import slavin.fit.bstu.quest.Model.Request;
import slavin.fit.bstu.quest.Model.User;

public class SetContractorActivity extends AppCompatActivity {

    ListView list;
    int questId;
    List<User> listUsers = new ArrayList<User>();
    List<Request> listRequests = new ArrayList<Request>();
    List<Map<String, String>> data = new ArrayList<Map<String, String>>();
    SimpleAdapter adapter;
    AdapterView.AdapterContextMenuInfo info;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setcontractor);

        list = findViewById(R.id.list_allcontractors);

        registerForContextMenu(list);

        ActionBar actionBar = getSupportActionBar();
        actionBar.setHomeButtonEnabled(true);
        actionBar.setDisplayHomeAsUpEnabled(true);

        Bundle id = getIntent().getExtras();
        questId = id.getInt("id");

        NetworkService.getInstance()
                .getQuestApi()
                .GetRequests()
                .enqueue(new Callback<List<Request>>() {
                    @Override
                    public void onResponse(@NonNull Call<List<Request>> call, @NonNull Response<List<Request>> response) {
                        List<Request> requests = response.body();
                        for (Request request : requests)
                        {
                            if(request.getQuestId() == questId)
                                listRequests.add(request);
                        }
                        NetworkService.getInstance()
                                .getQuestApi()
                                .GetUsers()
                                .enqueue(new Callback<List<User>>() {
                                    @Override
                                    public void onResponse(@NonNull Call<List<User>> call, @NonNull Response<List<User>> response) {
                                        List<User> users = response.body();
                                        for (User user : users)
                                        {
                                            for(Request request : listRequests)
                                            {
                                                if(user.getId() == request.getUserId())
                                                    listUsers.add(user);
                                            }
                                        }
                                        for (User user : listUsers)
                                        {
                                            Map<String, String> datum = new HashMap<String, String>(2);
                                            Integer id = user.getId();
                                            datum.put("id", id.toString());
                                            datum.put("name", user.getLogin());
                                            data.add(datum);
                                        }
                                        adapter = new SimpleAdapter(SetContractorActivity.this, data, android.R.layout.simple_list_item_2,
                                                new String[] {"name", "id"}, new int[] {android.R.id.text1, android.R.id.text2});
                                        list.setAdapter(adapter);
                                        list.setOnItemClickListener(new AdapterView.OnItemClickListener(){
                                            @Override
                                            public void onItemClick(AdapterView<?> parent, View v, int position, long id)
                                            {
                                                Intent intent = new Intent(SetContractorActivity.this, CurrentUserActivity.class);
                                                Map<String, String> str = data.get(position);
                                                Integer needingId = Integer.parseInt(str.get("id"));
                                                intent.putExtra("id", needingId);
                                                startActivity(intent);
                                            }
                                        });
                                    }
                                    @Override
                                    public void onFailure(@NonNull Call<List<User>> call, @NonNull Throwable t) {
                                        Toast.makeText(SetContractorActivity.this, t.getMessage(), Toast.LENGTH_LONG).show();
                                        t.printStackTrace();
                                    }
                                });
                    }
                    @Override
                    public void onFailure(@NonNull Call<List<Request>> call, @NonNull Throwable t) {
                        Toast.makeText(SetContractorActivity.this, t.getMessage(), Toast.LENGTH_LONG).show();
                        t.printStackTrace();
                    }
                });

    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.setcontractor_contextmenu, menu);
    }

    @Override
    public boolean onContextItemSelected(MenuItem item) {
        info = (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();
        switch (item.getItemId()) {
            case R.id.select:
                AlertDialog.Builder builder2 = new AlertDialog.Builder(this);
                builder2.setTitle("Внимание").setPositiveButton("Да", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Map<String, String> str = data.get(info.position);
                        String name = str.get("name");
                        EditQuest(questId, name);
                    }
                }).setNegativeButton("Нет", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                }).setMessage("Выбрать этого исполнителя?");
                AlertDialog dialog2 = builder2.create();
                dialog2.show();
                return true;
            default:
                return super.onContextItemSelected(item);
        }
    }

    public void EditQuest(int questid, String username)
    {
        Quest quest = new Quest();
        quest.setContractor(username);

        NetworkService.getInstance()
                .getQuestApi()
                .EditQuest(questid, quest)
                .enqueue(new Callback<String>() {
                    @Override
                    public void onResponse(@NonNull Call<String> call, @NonNull Response<String> response) {
                        Toast.makeText(SetContractorActivity.this, response.body(), Toast.LENGTH_LONG).show();
                        SetContractorActivity.this.finish();
                    }

                    @Override
                    public void onFailure(@NonNull Call<String> call, @NonNull Throwable t) {
                        Toast.makeText(SetContractorActivity.this, t.getMessage(), Toast.LENGTH_LONG).show();
                        t.printStackTrace();
                    }
                });
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                this.finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
