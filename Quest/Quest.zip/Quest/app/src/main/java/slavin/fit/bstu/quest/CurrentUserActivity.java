package slavin.fit.bstu.quest;

import android.os.Bundle;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import slavin.fit.bstu.quest.API.NetworkService;
import slavin.fit.bstu.quest.Model.Image;
import slavin.fit.bstu.quest.Model.User;

public class CurrentUserActivity extends AppCompatActivity {

    String[] user_values = { "Логин: ", "Имя: ", "Способ связи: ", "Кол-во доступных квестов: "};
    private ListView countriesList;
    private ListView listView;
    private ImageView imageView;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_currentuser);

        ActionBar actionBar =getSupportActionBar();
        actionBar.setHomeButtonEnabled(true);
        actionBar.setDisplayHomeAsUpEnabled(true);

        countriesList = findViewById(R.id.constant_values);
        imageView = findViewById(R.id.imageView);
        listView = findViewById(R.id.list_of_data);

        final ArrayList<String> userNames = new ArrayList<String>();

        ArrayAdapter<String> adapter_const = new ArrayAdapter(this, android.R.layout.simple_list_item_1, user_values);
        countriesList.setAdapter(adapter_const);

        Bundle id = getIntent().getExtras();
        int userId = id.getInt("id");



        NetworkService.getInstance()
                .getQuestApi()
                .GetUser(userId)
                .enqueue(new Callback<User>() {
                    @Override
                    public void onResponse(@NonNull Call<User> call, @NonNull Response<User> response) {
                        User user = response.body();
                        Integer count = user.getCount_Quests();
                        userNames.add(user.getLogin());
                        userNames.add(user.getName());
                        userNames.add(user.getCommunication());
                        userNames.add(count.toString());

                        ArrayAdapter<String> adapter = new ArrayAdapter(CurrentUserActivity.this, android.R.layout.simple_list_item_1, userNames);
                        listView.setAdapter(adapter);
                    }

                    @Override
                    public void onFailure(@NonNull Call<User> call, @NonNull Throwable t) {
                        Toast.makeText(CurrentUserActivity.this, t.getMessage(), Toast.LENGTH_LONG).show();
                        t.printStackTrace();
                    }
                });
        NetworkService.getInstance()
                .getQuestApi()
                .GetImages()
                .enqueue(new Callback<List<Image>>() {
                    @Override
                    public void onResponse(@NonNull Call<List<Image>> call, @NonNull Response<List<Image>> response) {
                        List<Image> list = response.body();
                        for (Image image : list) {
                            if(image.getUserId() != null && image.getUserId() == userId)
                            {
                                Glide.with(getApplicationContext()).load(image.getImageRef()).into(imageView);
                            }
                        }
                    }

                    @Override
                    public void onFailure(@NonNull Call<List<Image>> call, @NonNull Throwable t) {
                        Toast.makeText(CurrentUserActivity.this, t.getMessage(), Toast.LENGTH_LONG).show();
                        t.printStackTrace();
                    }
                });
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                this.finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

}
