package slavin.fit.bstu.quest.ui.allUsers;

import android.app.SearchManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.SimpleAdapter;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProviders;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import slavin.fit.bstu.quest.API.NetworkService;
import slavin.fit.bstu.quest.HomeActivity;
import slavin.fit.bstu.quest.Model.User;
import slavin.fit.bstu.quest.R;
import slavin.fit.bstu.quest.CurrentUserActivity;

public class allUsersFragment extends Fragment {

    private ListView listView;
    private Button displayButton;
    View root;
    SimpleAdapter adapter;
    String query;
    SearchView searchView;
    List<Map<String, String>> data = new ArrayList<Map<String, String>>();

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        root = inflater.inflate(R.layout.fragment_allusers, container, false);

        listView = root.findViewById(R.id.list_users);
        displayButton = root.findViewById(R.id.search_button);

        setHasOptionsMenu(true);

        displayButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                display();
            }
        });

        return root;
    }

    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        // Inflate the menu; this adds items to the action bar if it is present.
        inflater.inflate(R.menu.options_menu, menu);
        SearchManager searchManager = (SearchManager) getActivity().getSystemService(Context.SEARCH_SERVICE);
        searchView = (SearchView) menu.findItem(R.id.search).getActionView();
        searchView.setSearchableInfo(searchManager.getSearchableInfo(getActivity().getComponentName()));
        // Здесь можно указать будет ли строка поиска изначально развернута или свернута в значок
        searchView.setIconifiedByDefault(true);

        SearchView.OnQueryTextListener textChangeListener = new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextChange(String cs) {
//                if (adapter != null)
//                    adapter.getFilter().filter(cs);
                return false;
            }

            @Override
            public boolean onQueryTextSubmit(String query) {
                display();
                return false;
            }
        };
        searchView.setOnQueryTextListener(textChangeListener);

        super.onCreateOptionsMenu(menu, inflater);

    }

    public void display() {
        data.clear();
        query = searchView.getQuery().toString();;
        NetworkService.getInstance()
                .getQuestApi()
                .GetUsers()
                .enqueue(new Callback<List<User>>() {
                    @Override
                    public void onResponse(@NonNull Call<List<User>> call, @NonNull Response<List<User>> response) {
                        List<User> list = response.body();
                        for (User user : list)
                        {
                            if (user.getLogin().equals(query))
                            {
                                Map<String, String> datum = new HashMap<String, String>(2);
                                Integer id = user.getId();
                                datum.put("id", id.toString());
                                datum.put("name", user.getLogin());
                                data.add(datum);
                            }
                            else if (searchView.getQuery().toString().isEmpty())
                            {
                                Map<String, String> datum = new HashMap<String, String>(2);
                                Integer id = user.getId();
                                datum.put("id", id.toString());
                                datum.put("name", user.getLogin());
                                data.add(datum);
                            }
                        }
                        adapter = new SimpleAdapter(root.getContext(), data, android.R.layout.simple_list_item_2,
                                new String[] {"name", "id"}, new int[] {android.R.id.text1, android.R.id.text2});
                        listView.setAdapter(adapter);
                        listView.setOnItemClickListener(new AdapterView.OnItemClickListener(){
                            @Override
                            public void onItemClick(AdapterView<?> parent, View v, int position, long id)
                            {
                                Intent intent = new Intent(getContext(), CurrentUserActivity.class);
                                Map<String, String> str = data.get(position);
                                Integer needingId = Integer.parseInt(str.get("id"));
                                intent.putExtra("id", needingId);
                                startActivity(intent);
                            }
                        });
                    }

                    @Override
                    public void onFailure(@NonNull Call<List<User>> call, @NonNull Throwable t) {
                        Toast.makeText(getActivity(), t.getMessage(), Toast.LENGTH_LONG).show();
                        t.printStackTrace();
                    }
                });
    }
}
